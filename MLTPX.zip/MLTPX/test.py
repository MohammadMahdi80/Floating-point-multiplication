import os, os.path
import sys
from PySide6.QtCore import *
from PySide6.QtGui import *
from PySide6.QtWidgets import *
import os
from PySide6 import *
from PySide6.QtCore import QUrl
from PySide6.QtGui import QGuiApplication
from PySide6.QtWebEngineWidgets import QWebEngineView
from sympy import E
import timer
from functools import partial
import time


def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)



class Widget(QWidget):
    def __init__(self, parent=None):
        global width, height
        super(Widget, self).__init__(parent)
        width = self.screen().geometry().width()
        height = self.screen().geometry().height()    

        
        self.setStyleSheet("background-color: #0d0d0d;")
        self.setFixedWidth(800)
        self.setFixedHeight(550)
        self.counter = 0
        self.lab_list = []
        self.btn_list = []
        self.led_list = []
        self.clk = 0
        with open('./result.txt','r') as f :
            self.lines = f.readlines()

        remarkimg = QLabel(self)
        remarkimg.setStyleSheet('''border-image: url(''' + './remark.png' + ''')''')
        remarkimg.resize(30,30)
        remarkimg.move(20, 20)
        remarkimg.show()

        remarktext = QLabel(self)
        remarktext .setText('"True result" is calculator result and "VHDL relust" is VHDL code result.')
        remarktext .setStyleSheet(f'background :#0d0d0d;font-size: 20px;color: #ff0bf3; font-family:Comic Sans MS;')
        remarktext .resize(800,30)
        remarktext .move(55, 20)
        remarktext .show()

        y = 50
        d = 100
        input1 = QLabel(self)
        input1 .setText('input 1: ')
        input1 .setStyleSheet(f'background :#0d0d0d;font-size: 20px;color: #dd0072; font-family:Comic Sans MS;')
        input1 .resize(100,30)
        input1 .move(55, y+d)
        input1 .show()

        input2 = QLabel(self)
        input2 .setText('input 2: ')
        input2 .setStyleSheet(f'background :#0d0d0d;font-size: 20px;color: #dd0072; font-family:Comic Sans MS;')
        input2 .resize(100,30)
        input2 .move(55, 2*y+d)
        input2 .show()

        testbenc = QLabel(self)
        testbenc .setText('VHDL result: ')
        testbenc .setStyleSheet(f'background :#0d0d0d;font-size: 20px;color: #dd0072; font-family:Comic Sans MS;')
        testbenc .resize(120,30)
        testbenc .move(55, 3*y+d)
        testbenc .show()

        trueres = QLabel(self)
        trueres .setText('True result: ')
        trueres .setStyleSheet(f'background :#0d0d0d;font-size: 20px;color: #dd0072; font-family:Comic Sans MS;')
        trueres .resize(120,30)
        trueres .move(55, 4*y+d)
        trueres .show()

        button1 = QPushButton('Next', self)
        button1.move(700, 500)
        button1.resize(70,30)
        button1.setStyleSheet("""QPushButton {background-color: #11f900;font-size:20px; font-family:Comic Sans MS;}
                                QPushButton:pressed {
                                background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,
                                              stop: 0 #dadbde, stop: 1 #f6f7fa);
                                }""")
        button1.clicked.connect(self.next)
        button1.show()

    
    def drawRectangles(self):
        
        try:
            self.input1d.close()
            self.input2d.close()
            self.trueResd.close()
            self.testbenchd.close()
            self.input1h.close()
            self.input2h.close()
            self.trueResh.close()
            self.testbenchh.close()
        except:
            pass
        
        input1 = self.lines[self.clk][:32]
        input2 = self.lines[self.clk][32:64]
        testbench = self.lines[self.clk][64:96]
        trueRes = self.lines[self.clk][96:104]


        y = 50
        d = 100
        xd = 200
        xh = 350
        self.input1d = QLabel(self)
        text = '+' + f"{int(input1[0:],2)}" if input1[0] == '0' else '-' + f"{int(input1[1:],2)}"
        self.input1d.setText(text)
        self.input1d.setStyleSheet(f'background :#0d0d0d;font-size: 20px;color: #d8fff6; font-family:Comic Sans MS;')
        self.input1d.resize(130,25)
        self.input1d.move(xd, y+d)
        self.input1d.show()

        self.input1h = QLabel(self)
        self.input1h.setText(f"{hex(int(input1,2))}")
        self.input1h.setStyleSheet(f'background :#0d0d0d;font-size: 20px;color: #d8fff6; font-family:Comic Sans MS;')
        self.input1h.resize(130,25)
        self.input1h.move(xh, y+d)
        self.input1h.show()

        
        self.input2d = QLabel(self)
        text = '+' + f"{int(input2[1:],2)}" if input2[0] == '0' else '-' + f"{int(input2[1:],2)}"
        self.input2d.setText(text)
        self.input2d.setStyleSheet(f'background :#0d0d0d;font-size: 20px;color: #d8fff6; font-family:Comic Sans MS;')
        self.input2d.resize(130,25)
        self.input2d.move(xd, 2*y+d)
        self.input2d.show()

        self.input2h = QLabel(self)
        self.input2h.setText(f"{hex(int(input2,2))}")
        self.input2h.setStyleSheet(f'background :#0d0d0d;font-size: 20px;color: #d8fff6; font-family:Comic Sans MS;')
        self.input2h.resize(130,25)
        self.input2h.move(xh, 2*y+d)
        self.input2h.show()


        self.testbenchd = QLabel(self)
        text = '+' + f"{int(testbench[1:],2)}" if testbench[0] == '0' else '-' + f"{int(testbench[1:],2)}"
        self.testbenchd.setText(text)
        self.testbenchd.setStyleSheet(f'background :#0d0d0d;font-size: 20px;color: #002dfc; font-family:Comic Sans MS;')
        self.testbenchd.resize(130,25)
        self.testbenchd.move(xd, 3*y+d)
        self.testbenchd.show()

        self.testbenchh = QLabel(self)
        self.testbenchh.setText(f"{hex(int(testbench,2))}")
        self.testbenchh.setStyleSheet(f'background :#0d0d0d;font-size: 20px;color: #002dfc; font-family:Comic Sans MS;')
        self.testbenchh.resize(130,25)
        self.testbenchh.move(xh, 3*y+d)
        self.testbenchh.show()
        

        self.trueResd = QLabel(self)
        text = '-' + f"{int(trueRes,16)-2147483648}" if int(trueRes[0], 16) >= 8 else '+' + f"{int(trueRes,16)}"
        self.trueResd.setText(text)
        self.trueResd.setStyleSheet(f'background :#0d0d0d;font-size: 20px;color: #2fff08; font-family:Comic Sans MS;')
        self.trueResd.resize(130,25)
        self.trueResd.move(xd, 4*y+d)
        self.trueResd.show()

        self.trueResh = QLabel(self)
        self.trueResh.setText(f"{hex(int(trueRes,16))}")
        self.trueResh.setStyleSheet(f'background :#0d0d0d;font-size: 20px;color: #2fff08; font-family:Comic Sans MS;')
        self.trueResh.resize(130,25)
        self.trueResh.move(xh, 4*y+d)
        self.trueResh.show()


        self.clk += 1    

    def next(self):
        self.drawRectangles()
        



if __name__ == "__main__":
    app = QApplication()
    w = Widget()
    w.setWindowState(Qt.WindowMaximized)
    # w.resize(1000,700)
    width = w.screen().geometry().width()
    height = w.screen().geometry().height()


    w.show()
    with open('style.qss', 'w') as f:
        f.write("""
        QListWidget {
            color: #FFFFFF;
            background-color: #33373B;
            }

            QListWidget::item {
            height: 50px;
            }

            QListWidget::item:selected {
            background-color: #2ABf9E;
            }

            /*QLabel {*/
            /*    background-color: #FFFFFF;*/
            /*    qproperty-alignment: AlignCenter*/
            /*}*/

            QTreeWidget {
            color: #FFFFFF;
            background-color: #33373B;
            font-size: 18px;
            }

            QTreeWidget::item:selected {
            background-color: #2ABf9E;
            }

            QLabel{
            color: #33373B;
            background-color: None;
            }

            QLineEdit {
            border: 2px solid gray;
            border-radius: 10px;
            padding: 0 8px;
            background: greenyellow;
            selection-background-color: darkgray;
            font-size: 18px;
            }

            QLineEdit[echoMode="2"] {
            lineedit-password-character: 9679;
            }

            QLineEdit:read-only {
            background: lightblue;
            }

            QPushButton {
            border: 2px solid #8f8f91;
            border-radius: 10px;
            background-color: #2ABf9E;
            min-width: 50px;
            }

            QPushButton:pressed {
            background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,
                                              stop: 0 #dadbde, stop: 1 #f6f7fa);
            }

            QPushButton:flat {
            border: none; /* no border for a flat push button */
            }

            QPushButton:default {
            border-color: navy; /* make the default button prominent */
            }

            QScrollBar:vertical {
            border: blue;
            background: orangered;
            border-radius: 10px;
            }

            QScrollBar:horizontal {
            border: blue;
            background: blue;
            border-radius: 10px;
            }
        """)

    with open("style.qss", "r") as f:
        _style = f.read()
        app.setStyleSheet(_style)
    
    sys.exit(app.exec())
    
    